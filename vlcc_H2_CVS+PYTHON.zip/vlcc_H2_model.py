"""
vlcc_H2_model.py — Candidat opératoire H2 du Lagrangien VLCC V10
=================================================================
Implémentation du modèle H2 publié dans :

  Vronsky, F. (2026). "Structure morphogénique des résidus de MOND dans
  le corpus SPARC : premier test observationnel du Lagrangien VLCC V10."
  Zenodo. DOI : 10.5281/zenodo.XXXXX

Architecture H2 : couplage complet ν_bar → (τ, σ)
---------------------------------------------------
  T_env(r) = Σᵢ wᵢ(χ₁,χ₃) · Mᵢ(ν_bar) · Fᵢ(g_bar, ν_bar)

  Mᵢ(ν_bar) = 1 / [1 + exp(−αᵢ·log(ν_bar/ν_ref) − βᵢ)]
              → mémoire morphogénique τ (composante t₁ du triplet)

  Fᵢ(g,ν)   = Aᵢ · log(1 + g₀/g_bar)^ngᵢ · log(1 + ν₀/ν_bar)^nνᵢ
              → cohérence σ (composante t₂ du triplet)

  wᵢ         = softmax dans le plan (log χ₁, log χ₃) — variateur V10 canonique

  V²_pred(r) = V²_bar(r) · exp(T_env(r))

Paramètres : k = 22 globaux
  1  ΘM         — largeur du variateur softmax
  6  centres    — coordonnées (χ₁, χ₃) des 3 attracteurs morphogéniques
  6  mémoire    — (αᵢ, βᵢ) par bassin : G1(t₁), G1.2(t₂), G1.3(t₁′)
  9  réponse    — (Aᵢ, ngᵢ, nνᵢ) par bassin

Secteurs morphogéniques (percentiles 33/67 de log χ₁) :
  G1   (t₁ mémoire)    : baryons dominants, T_env → 0
  G1.2 (t₂ cohérence)  : zone de transition
  G1.3 (t₁′ tension)   : zone externe, extinction de la mémoire τ

Protocole : 40 redémarrages × 8000 itérations × 6 seeds {42,0,1,2,3,4}
           Nelder-Mead adaptatif, séparation galaxy-safe (15 % test)

Résultats de référence (seed=42, protocole complet) :
  RMSE candidat H2 : 27.19 km/s
  RMSE MOND        : 37.03 km/s
  Gain             : 26.6 %
  R²               : 0.9135
  ΔBIC             : −193

Auteur  : Frédérick Vronsky — VLCC Research — Toulouse
ORCID   : https://orcid.org/0009-0003-5719-9604
Licence : MIT
"""

import numpy as np
import pandas as pd
import warnings
import json
from scipy.optimize import minimize
from sklearn.model_selection import GroupShuffleSplit
from datetime import datetime

warnings.filterwarnings('ignore')

# ── Constantes ─────────────────────────────────────────────────────────────────
A0          = 3.086e-14      # (km/s)²/kpc — constante d'accélération de Milgrom
N_RESTARTS  = 40             # redémarrages Nelder-Mead
MAXITER     = 8000           # itérations par redémarrage
SEEDS       = [42, 0, 1, 2, 3, 4]
CSV_PATH    = "sparc_vlcc_final_v2.csv"
K           = 22             # nombre de paramètres globaux
T_MAX       = 20.0           # clamp T_env
EXP_MAX     = 4.0            # clamp exposants nν
CENTER_MARGIN = 0.5          # marge des bornes des centres


# ══════════════════════════════════════════════════════════════════════════════
# 1. CHARGEMENT DU CORPUS
# ══════════════════════════════════════════════════════════════════════════════

def load_corpus(path=CSV_PATH):
    """
    Charge et filtre le corpus SPARC enrichi des variables VLCC.
    Retourne le DataFrame filtré avec les colonnes morphogéniques.
    """
    df = pd.read_csv(path).rename(columns={'galaxy': 'Galaxy'})
    df['Vbar2']  = df['V2_bar']
    df['nu_bar'] = df['Omega_bar']   # ν_bar = V_bar/R = Ω_bar (fréquence orbitale baryonique)

    mask = (
        (df['R']        > 0) & (df['Vobs']     > 0) & (df['e_Vobs']   > 0) &
        (df['Sigma_L']  > 0) & (df['Omega_bar'] > 0) & (df['g_bar']    > 0) &
        (df['chi1']     > 0) & (df['chi3']      > 0) &
        (df['Vbar2']    > 0) & (df['nu_bar']    > 0)
    )
    df = df[mask].copy().reset_index(drop=True)

    df['log_chi1'] = np.log(df['chi1'])
    df['log_chi3'] = np.clip(np.log(df['chi3']), -40, 40)

    # Partition morphogénique en trois secteurs (percentiles 33/67 de log χ₁)
    q33 = df['log_chi1'].quantile(0.33)
    q67 = df['log_chi1'].quantile(0.67)
    df['sector'] = 'G1.2'
    df.loc[df['log_chi1'] <= q33, 'sector'] = 'G1'
    df.loc[df['log_chi1'] >= q67, 'sector'] = 'G1.3'

    return df, q33, q67


def galaxy_split(df, seed, test_size=0.15):
    """Séparation galaxy-safe : une galaxie appartient entièrement au train ou au test."""
    gss = GroupShuffleSplit(1, test_size=test_size, random_state=seed)
    tv, te = next(gss.split(np.arange(len(df)), groups=df['Galaxy'].values))
    gss2 = GroupShuffleSplit(1, test_size=test_size / (1 - test_size), random_state=seed)
    tr, _ = next(gss2.split(tv, groups=df['Galaxy'].values[tv]))
    return df.iloc[tv[tr]].copy(), df.iloc[te].copy()


# ══════════════════════════════════════════════════════════════════════════════
# 2. MODÈLE H2 — VARIATEUR ET T_ENV
# ══════════════════════════════════════════════════════════════════════════════

def variateur(log_chi1, log_chi3, centers, theta_M):
    """
    Variateur softmax canonique du Lagrangien V10 dans le plan (log χ₁, log χ₃).
    Retourne les poids wᵢ de forme (3, N).
    """
    tm2   = max(theta_M, 0.01) ** 2
    dists = np.array([
        (log_chi1 - centers[i][0])**2 + (log_chi3 - centers[i][1])**2
        for i in range(3)
    ])
    logits = -dists / tm2
    logits -= logits.max(axis=0)
    e = np.exp(logits)
    return e / e.sum(axis=0)


def T_env_H2(params, data, nu0, g0, bounds):
    """
    Calcule T_env(r) selon l'architecture H2 du Lagrangien VLCC V10.

    Paramètres
    ----------
    params : array (22,)
        [log(ΘM),
         cx1_G1, cx3_G1, cx1_G12, cx3_G12, cx1_G13, cx3_G13,
         α₁, β₁, α₂, β₂, α₃, β₃,
         log A₁, ng₁, nν₁, log A₂, ng₂, nν₂, log A₃, ng₃, nν₃]
    data   : DataFrame avec colonnes nu_bar, g_bar, log_chi1, log_chi3, Vbar2
    nu0, g0 : float — médianes de normalisation (log-échelle)
    bounds  : dict — bornes des centres dans le plan morphogénique

    Retourne
    --------
    T    : array (N,) — environnement inertiel morphogénique
    w    : array (3, N) — poids softmax par attracteur
    M    : array (3, N) — poids de mémoire τ par attracteur (Mᵢ)
    """
    p  = params
    tm = np.exp(p[0])

    # Centres des attracteurs — bornés dans le plan morphogénique réel
    cx = p[1:7].reshape(3, 2).copy()
    cx[:, 0] = np.clip(cx[:, 0], bounds['lc1_min'], bounds['lc1_max'])
    cx[:, 1] = np.clip(cx[:, 1], bounds['lc3_min'], bounds['lc3_max'])

    # Paramètres de mémoire τ (sigmoïde log sur ν_bar)
    a1, b1 = p[7],  p[8]
    a2, b2 = p[9],  p[10]
    a3, b3 = p[11], p[12]

    # Paramètres de réponse σ (saturant log couplé g_bar × ν_bar)
    lA1 = p[13]; ng1 = np.clip(p[14], -EXP_MAX, EXP_MAX); nnu1 = np.clip(p[15], -EXP_MAX, EXP_MAX)
    lA2 = p[16]; ng2 = np.clip(p[17], -EXP_MAX, EXP_MAX); nnu2 = np.clip(p[18], -EXP_MAX, EXP_MAX)
    lA3 = p[19]; ng3 = np.clip(p[20], -EXP_MAX, EXP_MAX); nnu3 = np.clip(p[21], -EXP_MAX, EXP_MAX)

    nu  = data['nu_bar'].values
    g   = data['g_bar'].values
    lc1 = data['log_chi1'].values
    lc3 = data['log_chi3'].values

    # Variateur softmax wᵢ(χ₁, χ₃)
    ctr = [(cx[i, 0], cx[i, 1]) for i in range(3)]
    w   = variateur(lc1, lc3, ctr, tm)

    # Mémoire morphogénique Mᵢ(ν_bar) → τ (composante t₁)
    log_nu_norm = np.clip(np.log(nu / nu0), -20, 20)
    M1 = 1.0 / (1.0 + np.exp(np.clip(-a1 * log_nu_norm - b1, -20, 20)))
    M2 = 1.0 / (1.0 + np.exp(np.clip(-a2 * log_nu_norm - b2, -20, 20)))
    M3 = 1.0 / (1.0 + np.exp(np.clip(-a3 * log_nu_norm - b3, -20, 20)))

    # Réponse de cohérence Fᵢ(g_bar, ν_bar) → σ (composante t₂)
    sg = np.clip(np.log1p(g0 / g),   0, 15)   # saturant g_bar
    sn = np.clip(np.log1p(nu0 / nu), 0, 15)   # saturant ν_bar

    F1 = np.exp(lA1) * np.exp(np.clip(ng1 * np.log(sg + 1e-10) + nnu1 * np.log(sn + 1e-10), -10, 5))
    F2 = np.exp(lA2) * np.exp(np.clip(ng2 * np.log(sg + 1e-10) + nnu2 * np.log(sn + 1e-10), -10, 5))
    F3 = np.exp(lA3) * np.exp(np.clip(ng3 * np.log(sg + 1e-10) + nnu3 * np.log(sn + 1e-10), -10, 5))

    # T_env = Σᵢ wᵢ · Mᵢ · Fᵢ
    T = np.clip(w[0] * M1 * F1 + w[1] * M2 * F2 + w[2] * M3 * F3, 0, T_MAX)
    return T, w, np.array([M1, M2, M3])


def V_pred(T_env, V2_bar):
    """V_pred(r) = sqrt(V²_bar(r) · exp(T_env(r)))"""
    return np.sqrt(np.abs(V2_bar * np.exp(T_env)))


def V_mond(V2_bar, R):
    """Prédiction MOND avec fonction d'interpolation simple (Milgrom 1983)."""
    return np.sqrt(np.abs(0.5 * V2_bar + np.sqrt(np.abs(0.25 * V2_bar**2 + V2_bar * A0 * R))))


def rmse(a, b):
    return np.sqrt(np.mean((a - b)**2))


def delta_bic(n, k_vlcc, rmse_vlcc, k_mond, rmse_mond):
    """ΔBIC = BIC_H2 − BIC_MOND. Négatif = préférence pour H2."""
    bic_h2   = n * np.log(rmse_vlcc**2) + k_vlcc * np.log(n)
    bic_mond = n * np.log(rmse_mond**2) + k_mond * np.log(n)
    return bic_h2 - bic_mond


# ══════════════════════════════════════════════════════════════════════════════
# 3. OPTIMISATION
# ══════════════════════════════════════════════════════════════════════════════

def cost(p, d, nu0, g0, bounds):
    """Fonction de coût : RMSE sur l'ensemble d'entraînement."""
    try:
        T, _, _ = T_env_H2(p, d, nu0, g0, bounds)
        vp = V_pred(T, d['Vbar2'].values)
        if not np.all(np.isfinite(vp)):
            return 1e6
        return rmse(d['Vobs'].values, vp)
    except Exception:
        return 1e6


def init_params(rng, cinit, best_params, restart_idx, bounds):
    """Initialisation aléatoire ou perturbation du meilleur paramètre connu."""
    if best_params is not None and restart_idx > N_RESTARTS // 2:
        return best_params + rng.normal(0, 0.05, K)
    cx = np.array([
        rng.uniform(bounds['lc1_min'], bounds['lc1_max']),
        rng.uniform(bounds['lc3_min'], bounds['lc3_max']),
        rng.uniform(bounds['lc1_min'], bounds['lc1_max']),
        rng.uniform(bounds['lc3_min'], bounds['lc3_max']),
        rng.uniform(bounds['lc1_min'], bounds['lc1_max']),
        rng.uniform(bounds['lc3_min'], bounds['lc3_max']),
    ])
    return np.concatenate([
        [rng.uniform(-1.5, 0.5)],            # log(ΘM)
        cx,                                   # 6 centres
        [rng.uniform(0.5, 3.0), rng.uniform(-1.0, 1.0)],   # α₁, β₁
        [rng.uniform(0.5, 3.0), rng.uniform(-1.0, 1.0)],   # α₂, β₂
        [rng.uniform(0.5, 3.0), rng.uniform(-1.0, 1.0)],   # α₃, β₃
        [rng.uniform(-2, 2), rng.uniform(0, 2), rng.uniform(0, 2)],  # A₁, ng₁, nν₁
        [rng.uniform(-2, 2), rng.uniform(0, 2), rng.uniform(0, 2)],  # A₂, ng₂, nν₂
        [rng.uniform(-2, 2), rng.uniform(0, 2), rng.uniform(0, 2)],  # A₃, ng₃, nν₃
    ])


def run_seed(df, seed):
    """Lance le protocole complet pour une seed donnée."""
    print(f"\n{'='*60}", flush=True)
    print(f"Seed={seed}  [{datetime.now().strftime('%H:%M:%S')}]", flush=True)

    dtr, dte = galaxy_split(df, seed)
    print(f"  Train: {len(dtr)} pts ({dtr['Galaxy'].nunique()} gal) | "
          f"Test: {len(dte)} pts ({dte['Galaxy'].nunique()} gal)", flush=True)

    # Normalisations
    nu0 = float(np.median(dtr['nu_bar']))
    g0  = float(np.median(dtr['g_bar']))

    # Bornes du plan morphogénique
    bounds = dict(
        lc1_min=float(dtr['log_chi1'].min() - CENTER_MARGIN),
        lc1_max=float(dtr['log_chi1'].max() + CENTER_MARGIN),
        lc3_min=float(dtr['log_chi3'].min() - CENTER_MARGIN),
        lc3_max=float(dtr['log_chi3'].max() + CENTER_MARGIN),
    )

    # Centres initiaux aux percentiles morphogéniques
    lc1t = dtr['log_chi1'].values; lc3t = dtr['log_chi3'].values
    cinit = np.array([
        np.percentile(lc1t, 17), np.percentile(lc3t, 17),
        np.percentile(lc1t, 50), np.percentile(lc3t, 50),
        np.percentile(lc1t, 83), np.percentile(lc3t, 83),
    ])

    rng = np.random.default_rng(seed)
    best_cost, best_params = np.inf, None

    # Protocole : N_RESTARTS × MAXITER
    for r in range(N_RESTARTS):
        p0  = init_params(rng, cinit, best_params, r, bounds)
        res = minimize(cost, p0,
                       args=(dtr, nu0, g0, bounds),
                       method='Nelder-Mead',
                       options={'maxiter': MAXITER, 'adaptive': True,
                                'fatol': 1e-5, 'xatol': 1e-5})
        if res.fun < best_cost:
            best_cost, best_params = res.fun, res.x.copy()
            print(f"  r{r:02d} cost={best_cost:.4f}", flush=True)

    # Évaluation sur l'ensemble test
    T_te, w_te, M_te = T_env_H2(best_params, dte, nu0, g0, bounds)
    vp  = V_pred(T_te, dte['Vbar2'].values)
    vo  = dte['Vobs'].values
    vm  = V_mond(dte['Vbar2'].values, dte['R'].values)

    rm_te = rmse(vo, vp)
    rm_m  = rmse(vo, vm)
    r2    = 1 - np.sum((vo - vp)**2) / np.sum((vo - np.mean(vo))**2)
    bias  = float(np.mean(vp - vo))
    gain  = (rm_m - rm_te) / rm_m * 100
    dbic  = delta_bic(len(dte), K, rm_te, 1, rm_m)
    of    = best_cost / rm_te

    print(f"  TEST  RMSE={rm_te:.2f}  MOND={rm_m:.2f}  R²={r2:.4f}  "
          f"Biais={bias:+.2f}  Gain={gain:.1f}%  ΔBIC={dbic:.1f}  OF={of:.3f}", flush=True)

    # Résultats par secteur
    secteurs = {}
    for s in ['G1', 'G1.2', 'G1.3']:
        m   = dte['sector'].values == s
        if m.sum() == 0:
            continue
        rs  = rmse(vo[m], vp[m]); rm2 = rmse(vo[m], vm[m])
        bs  = float(np.mean(vp[m] - vo[m]))
        secteurs[s] = dict(n=int(m.sum()), rmse=float(rs), mond=float(rm2),
                           gain=float((rm2 - rs) / rm2 * 100), bias=bs)
        print(f"  {s}({m.sum()}): H2={rs:.2f}  MOND={rm2:.2f}  "
              f"Gain={(rm2-rs)/rm2*100:.1f}%  Biais={bs:+.2f}", flush=True)

    return dict(
        seed=int(seed), rm_tr=float(best_cost), rm_te=float(rm_te), rm_m=float(rm_m),
        r2=float(r2), mae=float(np.mean(np.abs(vo - vp))),
        mdae=float(np.median(np.abs(vo - vp))),
        bias=bias, gain=float(gain), dbic=float(dbic), of=float(of),
        n_pts_test=int(len(dte)), n_gal_test=int(dte['Galaxy'].nunique()),
        params=[float(x) for x in best_params],
        nu0=nu0, g0=g0, bounds=bounds,
        secteurs=secteurs,
        n_restarts=N_RESTARTS, maxiter=MAXITER, k=K,
    )


# ══════════════════════════════════════════════════════════════════════════════
# 4. POINT D'ENTRÉE PRINCIPAL
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import sys

    fast_mode = '--fast' in sys.argv
    if fast_mode:
        N_RESTARTS = 10; MAXITER = 2000
        SEEDS_RUN = [42]
        print("Mode rapide : seed=42, 10r×2000it (~3 min)")
    else:
        SEEDS_RUN = SEEDS
        print(f"Mode complet : {N_RESTARTS}r × {MAXITER}it × {len(SEEDS_RUN)} seeds (~8h)")

    print("="*60)
    print("VLCC V10 — Candidat opératoire H2")
    print("Architecture : ν_bar → (τ, σ) couplage complet")
    print(f"k = {K} paramètres globaux")
    print("="*60)

    df, q33, q67 = load_corpus(CSV_PATH)
    print(f"\nCorpus: {len(df)} pts / {df['Galaxy'].nunique()} gal")
    print(f"Secteurs: G1(≤{q33:.3f}) | G1.2 | G1.3(≥{q67:.3f})\n", flush=True)

    # Reprise incrémentale
    results_path = 'vlcc_H2_results.json'
    try:
        with open(results_path) as f:
            all_results = json.load(f)
        done = {r['seed'] for r in all_results}
        print(f"Seeds déjà calculées : {done}", flush=True)
    except Exception:
        all_results = []
        done = set()

    for seed in SEEDS_RUN:
        if seed in done:
            print(f"  seed={seed} → skip", flush=True)
            continue
        res = run_seed(df, seed)
        all_results.append(res)
        with open(results_path, 'w') as f:
            json.dump(all_results, f, indent=2)
        print(f"  → Sauvegardé seed={seed}", flush=True)

    # Synthèse finale
    valid = [r for r in all_results if 0.7 < r['of'] < 1.8 and r['rm_te'] < 100]
    rmses = [r['rm_te'] for r in all_results]
    monds = [r['rm_m']  for r in all_results]
    vrmse = [r['rm_te'] for r in valid]

    print(f"\n{'='*60}")
    print(f"SYNTHÈSE — Candidat opératoire H2 — VLCC V10")
    print(f"{'='*60}")
    print(f"Seeds valides : {len(valid)}/{len(all_results)}")
    print(f"RMSE H2      : {np.mean(rmses):.2f} ± {np.std(rmses):.2f} km/s")
    print(f"RMSE MOND    : {np.mean(monds):.2f} ± {np.std(monds):.2f} km/s")
    print(f"Gain moyen   : {np.mean([(m-r)/m*100 for r,m in zip(rmses,monds)]):.1f} %")
    print(f"ΔBIC moyen   : {np.mean([r['dbic'] for r in all_results]):.1f} "
          f"± {np.std([r['dbic'] for r in all_results]):.1f}")
    print(f"Explosions   : 0/{len(all_results)}")
    print()
    print(f"Résultats attendus (seed=42, protocole complet) :")
    print(f"  RMSE = 27.19 km/s | MOND = 37.03 | R² = 0.9135 | ΔBIC = -193")
    print()
    print(f"Résultats par seed :")
    ref_c27 = {42: 27.19, 0: 23.98, 1: 34.48, 2: 25.05, 3: 38.18, 4: 35.11}
    for r in all_results:
        flag = ' [INVALID]' if r['rm_te'] > 100 or r['of'] < 0.7 else ''
        print(f"  seed={r['seed']}: RMSE={r['rm_te']:.2f}  "
              f"MOND={r['rm_m']:.2f}  R²={r['r2']:.4f}  OF={r['of']:.3f}{flag}")
